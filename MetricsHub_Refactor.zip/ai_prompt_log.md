# AI Prompt Log

1. Prompt: “Khi một phần tử cần chiếm 2 hàng và 2 cột xen kẽ với các phần tử nhỏ, nên dùng CSS Grid hay Flexbox? Vì sao?”
   - Kết quả áp dụng: Chọn CSS Grid cho Bento Dashboard và dùng `span`.

2. Prompt: “Trong Bootstrap 5, `col-sm-4` và `col-md-4` khác nhau thế nào?”
   - Kết quả áp dụng: Dùng `col-12 col-md-4` để mobile xếp dọc, desktop chia 3 cột.

3. Prompt: “Làm thế nào để navbar Flexbox tự xuống dòng trên màn hình nhỏ?”
   - Kết quả áp dụng: Dùng `flex-wrap: wrap` và cho vùng menu chiếm 100% ở mobile.

4. Prompt: “Thuộc tính `gap` dùng được với Grid và Flexbox không?”
   - Kết quả áp dụng: Dùng `gap` cho navbar và dashboard để thay các margin rời rạc.
